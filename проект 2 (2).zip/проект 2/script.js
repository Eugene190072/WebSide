document.querySelector('.btnIncrease').onclick = function() {
    let img = document.querySelector('.wonder');
    let btnIncrease = document.querySelector('.btnIncrease');
    let info = document.querySelector('.info');
    
    btnIncrease.style.display = 'none';
    info.style.display = 'none';

    img.style.transition = 'all 1s ease'
    img.style.position = 'fixed';
    img.style.top = '50%';
    img.style.left = '50%';
    img.style.transform = 'translate(-50%, -50%) scale(1.5)';
    img.style.zIndex = '999';
    
    let overlay = document.createElement('div');
    overlay.style.position = 'fixed';
    overlay.style.top = '0';
    overlay.style.left = '0';
    overlay.style.width = '100%';
    overlay.style.height = '100%';
    overlay.style.backgroundColor = 'rgba(0, 0, 0, 0.5)';
    overlay.style.zIndex = '998';
    
    let HelpText = document.createElement('h3');
    HelpText.innerText = 'Нажмите на фон, чтобы закрыть изображение';
    HelpText.style.position = 'fixed';
    HelpText.style.bottom = '20px';
    HelpText.style.left = '50%';
    HelpText.style.transform = 'translateX(-50%)';
    HelpText.style.color = 'white';
    HelpText.style.zIndex = '1000';
    
    document.body.appendChild(overlay);
    document.body.appendChild(HelpText);

    overlay.onclick = function() {
        img.style.position = '';
        img.style.top = '';
        img.style.left = '';
        img.style.transform = '';
        img.style.zIndex = '';
        img.style.filter = 'brightness(100%)';
        overlay.remove();
        HelpText.remove();
        
        btnIncrease.style.display = '';
        info.style.display = '';
    }
}